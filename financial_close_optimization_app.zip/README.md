# Step Up — Financial Close Optimization App

An interactive web application for managing and optimizing the monthly financial close process for nonprofit organizations. Built for **GAAP** and **2 CFR Part 200** compliance, with support for internal and outsourced accounting team coordination.

---

## Live Demo

> Once deployed, replace this line with your GitHub Pages URL:
> **https://your-username.github.io/stepup-financial-close/**

---

## Features

- **Financial Dashboard** — Eight-year overview (2016–2023) of revenue, expenses, and net assets with an interactive Chart.js visualization
- **Close Calendar** — Day-by-day (Day 1–15) task schedule with owner assignments and clickable status checkboxes
- **JE Checklist** — 22-item pre-posting journal entry checklist with live progress tracking
- **Bottleneck Analysis** — Top 5 nonprofit close process bottlenecks with data-driven recommendations
- **Automation Tools** — Curated list of 8 tools prioritized for small-to-mid nonprofit environments
- **Handoff Protocol** — Fillable template for internal ↔ outsourced team transitions

---

## Tech Stack

- Pure HTML, CSS, JavaScript — no build tools or frameworks required
- [Chart.js 4.4.1](https://www.chartjs.org/) via CDN for data visualization
- Zero dependencies to install

---

## Local Development

No installation needed. Simply open the file in your browser:

```bash
# Clone the repository
git clone https://github.com/your-username/stepup-financial-close.git

# Navigate into the folder
cd stepup-financial-close

# Open in browser (macOS)
open index.html

# Open in browser (Windows)
start index.html

# Open in browser (Linux)
xdg-open index.html
```

---

## Deployment

This app is deployed via **GitHub Pages**. See the step-by-step instructions below or in [DEPLOYMENT.md](./DEPLOYMENT.md).

---

## Project Structure

```
stepup-financial-close/
├── index.html          # Main application (single file)
├── README.md           # Project overview (this file)
├── DEPLOYMENT.md       # Step-by-step deployment guide
└── .gitignore          # Files to exclude from Git
```

---

## Compliance Notes

- Follows **Generally Accepted Accounting Principles (GAAP)**
- Compliant with **2 CFR Part 200** Uniform Administrative Requirements for federal grant recipients
- Designed for organizations with outsourced third-party accounting teams

---

## License

This project is for internal organizational use. All financial data shown is specific to Step Up.
