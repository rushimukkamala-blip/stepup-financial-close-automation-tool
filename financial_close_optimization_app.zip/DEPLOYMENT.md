# Deployment Guide — GitHub Pages

This guide walks you through deploying the Step Up Financial Close App as a live website using **GitHub Pages** — completely free, no server required.

---

## Prerequisites

- A free [GitHub account](https://github.com/signup)
- [Git](https://git-scm.com/downloads) installed on your computer
- The project files: `index.html`, `README.md`, `DEPLOYMENT.md`, `.gitignore`

---

## Step 1 — Create a New GitHub Repository

1. Go to [https://github.com/new](https://github.com/new)
2. Fill in the form:
   - **Repository name:** `stepup-financial-close`
   - **Description:** `Interactive financial close optimization app for Step Up`
   - **Visibility:** Choose **Public** (required for free GitHub Pages) or **Private** (requires GitHub Pro)
   - Leave "Initialize this repository" **unchecked** — you'll push files manually
3. Click **"Create repository"**
4. Copy the repository URL shown on the next screen — it will look like:
   ```
   https://github.com/your-username/stepup-financial-close.git
   ```

---

## Step 2 — Prepare Your Local Files

Make sure all four files are in the same folder on your computer:

```
stepup-financial-close/
├── index.html
├── README.md
├── DEPLOYMENT.md
└── .gitignore
```

> **Important:** The main HTML file must be named `index.html` (not `StepUp_FinancialClose_App.html`) for GitHub Pages to serve it correctly. Rename it if needed.

---

## Step 3 — Initialize Git and Push Files

Open your terminal (Mac/Linux) or Git Bash (Windows) and run these commands one by one:

```bash
# 1. Navigate to your project folder
cd path/to/stepup-financial-close

# 2. Initialize a new Git repository
git init

# 3. Add all files to staging
git add .

# 4. Create your first commit
git commit -m "Initial commit — Step Up financial close app"

# 5. Set the default branch name to 'main'
git branch -M main

# 6. Connect your local repo to GitHub (paste your URL from Step 1)
git remote add origin https://github.com/your-username/stepup-financial-close.git

# 7. Push your files to GitHub
git push -u origin main
```

After running these, refresh your GitHub repository page — your files should appear.

---

## Step 4 — Enable GitHub Pages

1. Go to your repository on GitHub
2. Click the **"Settings"** tab (top navigation bar)
3. In the left sidebar, click **"Pages"**
4. Under **"Branch"**, change the dropdown from `None` to **`main`**
5. Make sure the folder is set to **`/ (root)`**
6. Click **"Save"**

GitHub will show a banner:
> *"Your site is being deployed..."*

---

## Step 5 — Access Your Live URL

Wait 1–2 minutes, then refresh the Pages settings page. You'll see:

> **Your site is live at:**
> `https://your-username.github.io/stepup-financial-close/`

Click the link to confirm the app loads correctly.

---

## Step 6 — Share the URL

Copy the URL and share it with your team. Anyone with the link can open the app in their browser — no login required.

---

## Updating the App in the Future

Whenever you make changes to `index.html`, push the update and GitHub Pages will redeploy automatically (usually within 1–2 minutes):

```bash
# After making edits to index.html
git add index.html
git commit -m "Update close calendar tasks"
git push
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| Page shows 404 error | Make sure the file is named exactly `index.html` (lowercase) |
| Changes not showing | Wait 2–3 minutes and hard-refresh the browser (Ctrl+Shift+R) |
| "Permission denied" on push | Confirm you're logged into the correct GitHub account in your terminal |
| Private repo, Pages not working | GitHub Pages for private repos requires a paid GitHub plan |
| Chart not loading | Check your internet connection — Chart.js loads from a CDN |

---

## Optional: Custom Domain

If you have your own domain (e.g. `finance.stepup.org`):

1. In repository **Settings → Pages**, enter your domain under **"Custom domain"**
2. Add a `CNAME` file to your repo containing your domain name
3. Update your domain's DNS settings to point to GitHub Pages (see [GitHub's DNS guide](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site))
